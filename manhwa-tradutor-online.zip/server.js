'use strict';

const express = require('express');
const cheerio = require('cheerio');
const dns = require('node:dns/promises');
const net = require('node:net');
const path = require('node:path');
const { Readable } = require('node:stream');

const app = express();
const PORT = process.env.PORT || 3000;
// Só para testes locais: permite buscar páginas em endereços privados.
const ALLOW_PRIVATE = process.env.ALLOW_PRIVATE === '1';

const UA =
  'Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36';

app.use(express.json({ limit: '300kb' }));
app.get('/', (_req, res) => res.sendFile(path.join(__dirname, 'index.html')));

/* ---------- segurança: nunca buscar endereços internos ---------- */

function isPrivateIp(ip) {
  if (net.isIPv4(ip)) {
    const [a, b] = ip.split('.').map(Number);
    return (
      a === 0 ||
      a === 10 ||
      a === 127 ||
      (a === 169 && b === 254) ||
      (a === 172 && b >= 16 && b <= 31) ||
      (a === 192 && b === 168) ||
      (a === 100 && b >= 64 && b <= 127) ||
      a >= 224
    );
  }
  const l = ip.toLowerCase();
  if (l.startsWith('::ffff:')) return isPrivateIp(l.slice(7));
  return l === '::1' || l === '::' || l.startsWith('fc') || l.startsWith('fd') || l.startsWith('fe80');
}

async function assertPublic(rawUrl) {
  let u;
  try {
    u = new URL(rawUrl);
  } catch {
    throw httpError(400, 'Link inválido.');
  }
  if (u.protocol !== 'http:' && u.protocol !== 'https:') throw httpError(400, 'Use um link http ou https.');
  if (ALLOW_PRIVATE) return u;
  const host = u.hostname.replace(/^\[|\]$/g, '');
  let addrs;
  if (net.isIP(host)) addrs = [{ address: host }];
  else {
    try {
      addrs = await dns.lookup(host, { all: true });
    } catch {
      throw httpError(502, 'Não encontrei esse site. Confira o link.');
    }
  }
  if (addrs.some((a) => isPrivateIp(a.address))) throw httpError(400, 'Esse endereço não é permitido.');
  return u;
}

function httpError(status, message) {
  const e = new Error(message);
  e.status = status;
  return e;
}

async function safeFetch(url, headers = {}, hops = 5) {
  let current = url;
  for (let i = 0; i <= hops; i++) {
    await assertPublic(current);
    const res = await fetch(current, {
      headers: { 'User-Agent': UA, ...headers },
      redirect: 'manual',
      signal: AbortSignal.timeout(25000),
    });
    if (res.status >= 300 && res.status < 400 && res.headers.get('location')) {
      current = new URL(res.headers.get('location'), current).href;
      continue;
    }
    return res;
  }
  throw httpError(502, 'Redirecionamentos demais.');
}

/* ---------- 1) ler a página do capítulo e achar as imagens ---------- */

const LAZY_ATTRS = ['data-src', 'data-lazy-src', 'data-original', 'data-url', 'data-lazy', 'data-echo', 'src'];
const READER_SELECTORS = [
  '#readerarea img',
  '.reading-content img',
  '.container-chapter-reader img',
  '.chapter-content img',
  '.chapter-container img',
  '#chapter-container img',
  '.read-container img',
  '.page-break img',
  '#viewer img',
  '.viewer img',
];
const JUNK = /(logo|banner|avatar|icon|loading|placeholder|spinner|sprite|\/ads?[\/_-]|emoji|button)/i;

function pickSrc($el) {
  for (const a of LAZY_ATTRS) {
    const v = ($el.attr(a) || '').trim();
    if (v && !v.startsWith('data:')) return v;
  }
  const ss = $el.attr('data-srcset') || $el.attr('srcset');
  if (ss) return ss.split(',')[0].trim().split(/\s+/)[0];
  return null;
}

function collectImages($, base) {
  let nodes = null;
  for (const sel of READER_SELECTORS) {
    const found = $(sel);
    if (found.length >= 3) {
      nodes = found.toArray();
      break;
    }
  }
  if (!nodes) {
    // Heurística: o contêiner com mais imagens costuma ser o leitor.
    const groups = new Map();
    $('img').each((_, el) => {
      $(el)
        .parents()
        .slice(0, 4)
        .each((__, p) => {
          if (!groups.has(p)) groups.set(p, []);
          groups.get(p).push(el);
        });
    });
    let max = 0;
    for (const list of groups.values()) max = Math.max(max, list.length);
    for (const list of groups.values()) {
      if (list.length >= Math.max(3, Math.ceil(max * 0.8))) {
        nodes = list;
        break; // o mais profundo que ainda cobre quase todas
      }
    }
    if (!nodes) nodes = $('img').toArray();
  }

  const seen = new Set();
  const out = [];
  for (const el of nodes) {
    const raw = pickSrc($(el));
    if (!raw) continue;
    let abs;
    try {
      abs = new URL(raw, base).href;
    } catch {
      continue;
    }
    if (JUNK.test(abs) || /\.svg(\?|$)/i.test(abs) || seen.has(abs)) continue;
    seen.add(abs);
    out.push(abs);
  }
  return out;
}

app.get('/api/chapter', async (req, res, next) => {
  try {
    const url = String(req.query.url || '').trim();
    if (!url) throw httpError(400, 'Cole o link do capítulo.');
    const origin = new URL(url).origin;
    const r = await safeFetch(url, {
      Accept: 'text/html,application/xhtml+xml',
      'Accept-Language': 'en-US,en;q=0.8',
      Referer: origin + '/',
    });
    if (!r.ok) throw httpError(502, `O site respondeu com erro ${r.status}. Ele pode estar bloqueando o acesso.`);
    const html = await r.text();
    const $ = cheerio.load(html);
    const images = collectImages($, r.url || url);
    if (!images.length) {
      throw httpError(
        422,
        'Não achei imagens nessa página. Alguns sites só carregam o capítulo com JavaScript ou exigem login.'
      );
    }
    res.json({ title: ($('title').first().text() || '').trim().slice(0, 140), page: url, images });
  } catch (e) {
    next(e);
  }
});

/* ---------- 2) proxy de imagens (evita bloqueio de hotlink e CORS) ---------- */

app.get('/api/img', async (req, res, next) => {
  try {
    const u = String(req.query.u || '');
    const ref = String(req.query.r || '') || new URL(u).origin + '/';
    const r = await safeFetch(u, { Accept: 'image/*,*/*;q=0.5', Referer: ref });
    if (!r.ok) throw httpError(502, `Imagem indisponível (${r.status}).`);
    const type = r.headers.get('content-type') || '';
    if (!type.startsWith('image/')) throw httpError(415, 'O link não é uma imagem.');
    const len = Number(r.headers.get('content-length') || 0);
    if (len > 30 * 1024 * 1024) throw httpError(413, 'Imagem grande demais.');
    res.set('Content-Type', type);
    res.set('Cache-Control', 'public, max-age=3600');
    Readable.fromWeb(r.body).on('error', () => res.destroy()).pipe(res);
  } catch (e) {
    next(e);
  }
});

/* ---------- 3) tradução para português ---------- */

const cache = new Map();

async function viaGoogle(text, from) {
  const u = new URL('https://translate.googleapis.com/translate_a/single');
  u.search = new URLSearchParams({ client: 'gtx', sl: from, tl: 'pt', dt: 't', q: text }).toString();
  const r = await fetch(u, { signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error('google ' + r.status);
  const j = await r.json();
  return j[0].map((s) => s[0]).join('');
}

async function viaMyMemory(text, from) {
  const u = new URL('https://api.mymemory.translated.net/get');
  u.search = new URLSearchParams({ q: text, langpair: `${from.split('-')[0]}|pt-BR` }).toString();
  const r = await fetch(u, { signal: AbortSignal.timeout(15000) });
  if (!r.ok) throw new Error('mymemory ' + r.status);
  const j = await r.json();
  const t = j && j.responseData && j.responseData.translatedText;
  if (!t) throw new Error('mymemory vazio');
  return t;
}

async function translateOne(text, from) {
  const key = from + '|' + text;
  if (cache.has(key)) return cache.get(key);
  let out;
  try {
    out = await viaGoogle(text, from);
  } catch {
    out = await viaMyMemory(text, from);
  }
  if (cache.size > 5000) cache.clear();
  cache.set(key, out);
  return out;
}

app.post('/api/translate', async (req, res, next) => {
  try {
    const { texts, from } = req.body || {};
    if (!Array.isArray(texts) || texts.length > 200) throw httpError(400, 'Pedido inválido.');
    const src = ['ko', 'ja', 'en', 'zh-CN'].includes(from) ? from : 'auto';
    const result = new Array(texts.length).fill('');
    let next_ = 0;
    const worker = async () => {
      while (next_ < texts.length) {
        const i = next_++;
        const t = String(texts[i] || '').slice(0, 600);
        if (!t.trim()) continue;
        try {
          result[i] = await translateOne(t, src);
        } catch {
          result[i] = ''; // o cliente mantém o original nesse balão
        }
      }
    };
    await Promise.all(Array.from({ length: 5 }, worker));
    res.json({ translations: result });
  } catch (e) {
    next(e);
  }
});

app.use((err, _req, res, _next) => {
  const status = err.status || 500;
  res.status(status).json({ error: status === 500 ? 'Erro inesperado no servidor.' : err.message });
});

app.listen(PORT, '0.0.0.0', () => console.log(`Tradutor de Capítulos em http://localhost:${PORT}`));
